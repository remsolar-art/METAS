import * as functions from 'firebase-functions'
import * as admin from 'firebase-admin'
import corsLib from 'cors'

admin.initializeApp()
const cors = corsLib({ origin: true })

// HTTP function: inviteUser (admin-only). Creates a user and sets role in Firestore.
export const inviteUser = functions.https.onRequest(async (req, res) => {
  cors(req, res, async () => {
    try {
      if (req.method !== 'POST') return res.status(405).send('Method Not Allowed')
      const { email, password, role } = req.body || {}
      if (!email || !password) return res.status(400).send('email e password são obrigatórios')
      const { authorization } = req.headers
      if (!authorization) return res.status(401).send('Missing Authorization')

      // Expect a Firebase ID token from an admin user in "Authorization: Bearer <token>"
      const token = authorization.replace('Bearer ', '')
      const decoded = await admin.auth().verifyIdToken(token)
      const uid = decoded.uid

      // Check role in Firestore
      const roleSnap = await admin.firestore().doc(`roles/${uid}`).get()
      if (!roleSnap.exists || roleSnap.data().role !== 'admin') {
        return res.status(403).send('Apenas admin pode convidar usuários.')
      }

      // Create user
      const userRecord = await admin.auth().createUser({ email, password })
      // Persist role in Firestore
      await admin.firestore().doc(`roles/${userRecord.uid}`).set({ role: role === 'admin' ? 'admin' : 'user', createdAt: admin.firestore.FieldValue.serverTimestamp() })

      res.status(200).json({ uid: userRecord.uid })
    } catch (err) {
      console.error(err)
      res.status(500).send(err.message || 'Erro interno')
    }
  })
})
