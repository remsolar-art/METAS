# App de Metas – Rodrigues Machado Serviços (Firebase)

CNPJ: 34.485.965/0001-33

Aplicativo com **login**, **sincronização em tempo real** (Firestore) e **controle de acesso** (admin x colaboradores).

## 1) Pré-requisitos
- Node.js 18+
- Conta Firebase
- Firebase CLI: `npm i -g firebase-tools`

## 2) Configuração Firebase (Web App)
1. Crie um projeto no Firebase Console.
2. Em *Authentication* > *Sign-in method*, habilite **Email/Password**.
3. Em *Firestore*, crie o banco em modo **production**.
4. Em *Project settings* > *General* > *Your apps*, crie um app **Web** e copie as credenciais.
5. Renomeie `.env.example` para `.env.local` e preencha as variáveis `VITE_FIREBASE_*`.

## 3) Regras de segurança
Aplicar regras de segurança do Firestore:
```bash
firebase deploy --only firestore:rules
```
Regras: `firestore.rules` (admin lê tudo; colaborador só vê/edita tarefas atribuídas a ele).

## 4) Função Cloud (inviteUser)
Permite que o **admin convide/crie usuários** e defina a função (admin/user).
```bash
cd functions
npm install
cd ..
firebase deploy --only functions
```
A função `inviteUser` será mapeada em Hosting (rewrite) para a rota `/inviteUser`.

## 5) Rodar localmente
```bash
npm install
npm run dev
```
Abra o endereço exibido (Vite).

## 6) Fluxo de acesso
- Faça login com o **admin** (por exemplo, `admin@rodriguesmachado.com`).
- No Firestore, crie manualmente um doc `roles/{UID_DO_ADMIN}` com `{ role: 'admin' }` (apenas uma vez).
- Use o painel **Convite de usuário** para cadastrar colaboradores (gera usuário e `roles/{uid}`).

## 7) Deploy (Hosting)
- Vercel/Netlify para front-end **ou** Firebase Hosting:
```bash
npm run build
firebase deploy --only hosting
```
(Se usar Hosting do Firebase, as rewrites para `/inviteUser` já estão no `firebase.json`).

## Notas
- O app consulta o doc `/roles/{uid}` para saber se o usuário é **admin** ou **user**.
- A regra do Firestore garante que colaboradores só vejam suas próprias tarefas.
- Para gerar APK Android, use Capacitor (ver README anterior).
