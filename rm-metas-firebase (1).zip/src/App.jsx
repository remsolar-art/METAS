import React, { useEffect, useMemo, useState } from 'react'
import { motion, AnimatePresence } from 'framer-motion'
import { Plus, Trash2, CheckCircle2, Download, Upload, Filter, TrendingUp, Users, Target, Factory, LogOut, UserPlus } from 'lucide-react'
import { auth, db } from './firebase'
import {
  onAuthStateChanged, signInWithEmailAndPassword, signOut,
} from 'firebase/auth'
import {
  collection, addDoc, doc, onSnapshot, orderBy, query, serverTimestamp, setDoc, updateDoc, deleteDoc, where,
} from 'firebase/firestore'

// Cloud Function callable (invite user)
async function inviteUser(email, password, role) {
  // Callable endpoint (em produção use onCall; aqui fazemos fetch simples para /inviteUser)
  const resp = await fetch('/inviteUser', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ email, password, role }),
  })
  if (!resp.ok) {
    const msg = await resp.text()
    throw new Error(msg || 'Falha ao convidar usuário')
  }
  return resp.json()
}

function uid() {
  return Math.random().toString(36).slice(2, 9) + Date.now().toString(36).slice(-4)
}

export default function App() {
  const [user, setUser] = useState(null)
  const [role, setRole] = useState('user') // 'admin' | 'user'
  const [loading, setLoading] = useState(true)

  useEffect(() => {
    const unsub = onAuthStateChanged(auth, async (u) => {
      setUser(u)
      if (u) {
        // role vem de um doc em /roles/{uid} para simplificar (custom claims exigem backend)
        const ref = doc(db, 'roles', u.uid)
        // leitura única:
        import('firebase/firestore').then(async ({ getDoc }) => {
          const snap = await getDoc(ref)
          setRole(snap.exists() ? (snap.data().role || 'user') : 'user')
          setLoading(false)
        })
      } else {
        setRole('user')
        setLoading(false)
      }
    })
    return () => unsub()
  }, [])

  if (loading) return <div className="p-6">Carregando...</div>

  return (
    <div className="min-h-screen bg-gray-50 text-gray-900">
      <Header user={user} role={role} />
      <main className="max-w-6xl mx-auto px-4 py-6">
        {!user ? <LoginForm /> : <TasksBoard user={user} role={role} />}
      </main>
      <Footer />
    </div>
  )
}

function Header({ user, role }) {
  return (
    <header className="sticky top-0 z-10 backdrop-blur bg-white/70 border-b">
      <div className="max-w-6xl mx-auto px-4 py-4 flex items-center justify-between">
        <div className="flex items-center gap-3">
          <div className="p-2 rounded-2xl bg-emerald-600 text-white shadow-md">
            <Factory className="w-6 h-6" />
          </div>
          <div>
            <h1 className="text-xl sm:text-2xl font-bold leading-tight">Rodrigues Machado Serviços LTDA</h1>
            <p className="text-xs sm:text-sm text-gray-600">CNPJ: 34.485.965/0001-33 • App de Metas e Tarefas</p>
          </div>
        </div>
        <div className="flex items-center gap-2">
          {user && <span className="text-xs text-gray-600">Logado como: {user.email} • {role}</span>}
          {user ? (
            <button onClick={() => signOut(auth)} className="inline-flex items-center gap-2 rounded-2xl px-3 py-2 bg-gray-900 text-white shadow hover:opacity-90">
              <LogOut className="w-4 h-4" /> Sair
            </button>
          ) : null}
        </div>
      </div>
    </header>
  )
}

function LoginForm() {
  const [email, setEmail] = useState('admin@rodriguesmachado.com')
  const [password, setPassword] = useState('admin123')

  async function login(e) {
    e.preventDefault()
    await signInWithEmailAndPassword(auth, email, password)
  }

  return (
    <form onSubmit={login} className="max-w-md mx-auto bg-white border rounded-2xl p-4 shadow-sm">
      <h2 className="text-lg font-semibold mb-3">Acesso</h2>
      <div className="grid gap-3">
        <div>
          <label className="text-xs text-gray-600">E-mail</label>
          <input value={email} onChange={e=>setEmail(e.target.value)} className="w-full px-3 py-2 rounded-2xl border bg-white" />
        </div>
        <div>
          <label className="text-xs text-gray-600">Senha</label>
          <input type="password" value={password} onChange={e=>setPassword(e.target.value)} className="w-full px-3 py-2 rounded-2xl border bg-white" />
        </div>
        <button type="submit" className="inline-flex items-center gap-2 rounded-2xl px-4 py-2 bg-emerald-600 text-white shadow hover:opacity-90">Entrar</button>
      </div>
      <p className="text-xs text-gray-600 mt-3">Admin padrão: admin@rodriguesmachado.com / admin123 (altere nas configurações do Firebase).</p>
    </form>
  )
}

function TasksBoard({ user, role }) {
  const [query, setQuery] = useState('')
  const [assigneeFilter, setAssigneeFilter] = useState('Todos')
  const [statusFilter, setStatusFilter] = useState('Todos')
  const [tasks, setTasks] = useState([])

  useEffect(() => {
    const col = collection(db, 'tasks')
    let q
    if (role === 'admin') {
      q = queryWrap(col)
    } else {
      q = queryWrap(col, where('assignedToUid', '==', user.uid))
    }
    const unsub = onSnapshot(q, snapshot => {
      const arr = snapshot.docs.map(d => ({ id: d.id, ...d.data() }))
      setTasks(arr)
    })
    return () => unsub()
  }, [user, role])

  const assignees = useMemo(() => {
    const set = new Set(tasks.map(t => t.assignedToName).filter(Boolean))
    return ['Todos', ...Array.from(set)]
  }, [tasks])

  const filtered = useMemo(() => {
    return tasks.filter(t => {
      const matchesQuery = [t.title, t.description, t.assignedToName]
        .filter(Boolean).join(' ').toLowerCase().includes(query.toLowerCase())
      const matchesAssignee = assigneeFilter === 'Todos' || t.assignedToName === assigneeFilter
      const done = (t.progress || 0) >= 100
      const matchesStatus = statusFilter === 'Todos' ||
        (statusFilter === 'Concluídas' && done) ||
        (statusFilter === 'Em andamento' && !done)
      return matchesQuery && matchesAssignee && matchesStatus
    })
  }, [tasks, query, assigneeFilter, statusFilter])

  const totals = useMemo(() => {
    const totalWeight = tasks.reduce((s, t) => s + (Number(t.weight) || 0), 0) || 0
    const weightedProgress = tasks.reduce((s, t) => s + (Number(t.weight) || 0) * (Number(t.progress) || 0), 0)
    const overall = totalWeight ? Math.round((weightedProgress / (totalWeight * 100)) * 100) : 0
    const completed = tasks.filter(t => (t.progress || 0) >= 100).length
    return { total: tasks.length, completed, overall, totalWeight }
  }, [tasks])

  async function addTask(t) {
    await addDoc(collection(db, 'tasks'), {
      ...t,
      createdAt: serverTimestamp(),
      createdByUid: user.uid,
      createdByEmail: user.email,
    })
  }

  async function removeTask(id) { await deleteDoc(doc(db, 'tasks', id)) }
  async function updateTask(id, patch) { await updateDoc(doc(db, 'tasks', id), patch) }

  return (
    <>
      <section className="grid grid-cols-1 sm:grid-cols-3 gap-4 mb-6">
        <StatCard title="Execução Geral (Ponderada)" value={`${totals.overall}%`} hint={`${totals.total} tarefas • Peso total ${totals.totalWeight}`} icon={<Target className="w-5 h-5" />} />
        <StatCard title="Concluídas" value={`${totals.completed}`} hint={`de ${totals.total}`} icon={<CheckCircle2 className="w-5 h-5" />} />
        <StatCard title="Em Andamento" value={`${totals.total - totals.completed}`} hint="tarefas ativas" icon={<TrendingUp className="w-5 h-5" />} />
      </section>

      {role === 'admin' && <AdminPanel onAddTask={addTask} />}

      <section className="mb-4">
        <div className="flex flex-col sm:flex-row gap-3 items-start sm:items-center justify-between">
          <div className="flex items-center gap-2 text-gray-600">
            <Filter className="w-4 h-4" />
            <span className="text-sm font-medium">Filtros</span>
          </div>
          <div className="flex flex-col sm:flex-row gap-3 w-full sm:w-auto">
            <input className="w-full sm:w-80 px-3 py-2 rounded-2xl border bg-white" placeholder="Buscar..." value={query} onChange={e=>setQuery(e.target.value)} />
            <select className="px-3 py-2 rounded-2xl border bg-white" value={assigneeFilter} onChange={(e)=>setAssigneeFilter(e.target.value)}>
              {assignees.map(a => <option key={a} value={a}>{a}</option>)}
            </select>
            <select className="px-3 py-2 rounded-2xl border bg-white" value={statusFilter} onChange={(e)=>setStatusFilter(e.target.value)}>
              {['Todos', 'Concluídas', 'Em andamento'].map(s => <option key={s} value={s}>{s}</option>)}
            </select>
          </div>
        </div>
      </section>

      <section className="grid grid-cols-1 gap-4">
        <AnimatePresence>
          {filtered.map(t => (
            <motion.div key={t.id} initial={{opacity:0,y:8}} animate={{opacity:1,y:0}} exit={{opacity:0,y:-8}} className="bg-white border rounded-2xl p-4 shadow-sm">
              <div className="flex items-start justify-between gap-4">
                <div className="flex-1">
                  <div className="flex items-center gap-2">
                    <input type="checkbox" className="w-5 h-5 accent-emerald-600" checked={(t.progress||0) >= 100} onChange={(e)=>updateTask(t.id, { progress: e.target.checked ? 100 : 0 })} />
                    <h3 className="text-lg font-semibold">{t.title}</h3>
                  </div>
                  <p className="text-sm text-gray-600 mt-1">{t.description}</p>

                  <div className="mt-3 grid grid-cols-1 sm:grid-cols-4 gap-3">
                    <div className="sm:col-span-2">
                      <label className="text-xs text-gray-600">Progresso: {t.progress || 0}%</label>
                      <input type="range" min={0} max={100} value={t.progress || 0} onChange={(e)=>updateTask(t.id, { progress: Number(e.target.value) })} className="w-full" />
                      <ProgressBar value={t.progress || 0} />
                    </div>
                    <div>
                      <label className="text-xs text-gray-600">Peso</label>
                      <input type="number" min={0} max={100} value={t.weight || 0} onChange={(e)=>updateTask(t.id, { weight: Number(e.target.value) })} className="w-full px-3 py-2 rounded-2xl border bg-white" />
                    </div>
                    <div>
                      <label className="text-xs text-gray-600">Prazo</label>
                      <input type="date" value={t.due || ''} onChange={(e)=>updateTask(t.id, { due: e.target.value })} className="w-full px-3 py-2 rounded-2xl border bg-white" />
                    </div>
                  </div>

                  <div className="mt-3 flex flex-wrap items-center gap-2 text-sm">
                    <span className="px-2 py-1 rounded-full bg-emerald-50 text-emerald-700 border border-emerald-200">{t.assignedToName || '(Sem atribuição)'}</span>
                    <span className={`px-2 py-1 rounded-full border ${(t.progress||0) >= 100 ? 'bg-emerald-600 text-white border-emerald-600' : 'bg-yellow-50 text-yellow-700 border-yellow-200'}`}>
                      {(t.progress||0) >= 100 ? 'Concluída' : 'Em andamento'}
                    </span>
                    {t.due && <span className="px-2 py-1 rounded-full bg-blue-50 text-blue-700 border border-blue-200">Vence em {formatDateBR(t.due)}</span>}
                    <span className="px-2 py-1 rounded-full bg-gray-50 text-gray-700 border border-gray-200">Peso {t.weight || 0}</span>
                  </div>
                </div>
                { (role === 'admin' || user.uid === t.assignedToUid) && (
                  <div className="flex flex-col items-end gap-2">
                    <button onClick={()=>removeTask(t.id)} className="p-2 rounded-xl bg-red-50 text-red-700 border border-red-200 hover:bg-red-100"><Trash2 className="w-4 h-4" /></button>
                  </div>
                )}
              </div>
            </motion.div>
          ))}
        </AnimatePresence>
        {filtered.length === 0 && <div className="text-center text-gray-600 py-12 border rounded-2xl bg-white">Nenhuma tarefa encontrada com os filtros atuais.</div>}
      </section>

      <section className="mt-8">
        <h2 className="text-lg font-semibold mb-3 flex items-center gap-2"><Users className="w-5 h-5" /> Resumo por Colaborador</h2>
        <PerAssignee tasks={tasks} />
      </section>
    </>
  )
}

function AdminPanel({ onAddTask }) {
  const [title, setTitle] = useState('')
  const [description, setDescription] = useState('')
  const [assignedToName, setAssignedToName] = useState('')
  const [assignedToUid, setAssignedToUid] = useState('')
  const [weight, setWeight] = useState(10)
  const [due, setDue] = useState('')
  const [inviteEmail, setInviteEmail] = useState('')
  const [invitePass, setInvitePass] = useState('123456')
  const [inviteRole, setInviteRole] = useState('user')
  const [msg, setMsg] = useState('')

  async function submitTask(e) {
    e.preventDefault()
    if (!title.trim() || !assignedToUid.trim()) return
    await onAddTask({ title, description, assignedToName, assignedToUid, weight: Number(weight)||0, progress: 0, due })
    setTitle(''); setDescription(''); setAssignedToName(''); setAssignedToUid(''); setWeight(10); setDue('')
  }

  async function doInvite(e) {
    e.preventDefault()
    setMsg('')
    try {
      const res = await inviteUser(inviteEmail, invitePass, inviteRole)
      setMsg(`Convite enviado. UID: ${res.uid}`)
    } catch (err) {
      setMsg(`Erro: ${err.message}`)
    }
  }

  return (
    <div className="grid md:grid-cols-2 gap-6 mb-6">
      <form onSubmit={submitTask} className="bg-white border rounded-2xl p-4 shadow-sm">
        <div className="flex items-center gap-2 mb-4"><div className="p-2 rounded-xl bg-emerald-600 text-white"><Plus className="w-4 h-4" /></div><h2 className="text-lg font-semibold">Nova tarefa / escopo</h2></div>
        <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
          <div className="sm:col-span-2">
            <label className="text-xs text-gray-600">Título</label>
            <input value={title} onChange={e=>setTitle(e.target.value)} className="w-full px-3 py-2 rounded-2xl border bg-white" placeholder="Ex.: Inspeção elétrica – UFV X" />
          </div>
          <div className="sm:col-span-2">
            <label className="text-xs text-gray-600">Descrição</label>
            <textarea value={description} onChange={e=>setDescription(e.target.value)} rows={3} className="w-full px-3 py-2 rounded-2xl border bg-white" />
          </div>
          <div>
            <label className="text-xs text-gray-600">Responsável (nome)</label>
            <input value={assignedToName} onChange={e=>setAssignedToName(e.target.value)} className="w-full px-3 py-2 rounded-2xl border bg-white" placeholder="Ex.: Líder João" />
          </div>
          <div>
            <label className="text-xs text-gray-600">Responsável (UID)</label>
            <input value={assignedToUid} onChange={e=>setAssignedToUid(e.target.value)} className="w-full px-3 py-2 rounded-2xl border bg-white" placeholder="Cole o UID do colaborador" />
          </div>
          <div>
            <label className="text-xs text-gray-600">Peso</label>
            <input type="number" min={0} max={100} value={weight} onChange={e=>setWeight(e.target.value)} className="w-full px-3 py-2 rounded-2xl border bg-white" />
          </div>
          <div>
            <label className="text-xs text-gray-600">Prazo</label>
            <input type="date" value={due} onChange={e=>setDue(e.target.value)} className="w-full px-3 py-2 rounded-2xl border bg-white" />
          </div>
        </div>
        <div className="mt-4"><button type="submit" className="inline-flex items-center gap-2 rounded-2xl px-4 py-2 bg-emerald-600 text-white shadow hover:opacity-90">Adicionar tarefa</button></div>
      </form>

      <form onSubmit={doInvite} className="bg-white border rounded-2xl p-4 shadow-sm">
        <div className="flex items-center gap-2 mb-4"><div className="p-2 rounded-xl bg-gray-900 text-white"><UserPlus className="w-4 h-4" /></div><h2 className="text-lg font-semibold">Convite de usuário</h2></div>
        <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
          <div className="sm:col-span-2"><label className="text-xs text-gray-600">E-mail</label><input value={inviteEmail} onChange={e=>setInviteEmail(e.target.value)} className="w-full px-3 py-2 rounded-2xl border bg-white" /></div>
          <div><label className="text-xs text-gray-600">Senha temporária</label><input value={invitePass} onChange={e=>setInvitePass(e.target.value)} className="w-full px-3 py-2 rounded-2xl border bg-white" /></div>
          <div><label className="text-xs text-gray-600">Função</label><select value={inviteRole} onChange={e=>setInviteRole(e.target.value)} className="w-full px-3 py-2 rounded-2xl border bg-white"><option value="user">Colaborador</option><option value="admin">Administrador</option></select></div>
        </div>
        <div className="mt-4">
          <button className="inline-flex items-center gap-2 rounded-2xl px-4 py-2 bg-gray-900 text-white shadow hover:opacity-90" type="submit">Convidar</button>
          {msg && <p className="text-xs text-gray-600 mt-2">{msg}</p>}
          <p className="text-xs text-gray-500 mt-2">Obs.: Requer a Cloud Function <code>inviteUser</code> ativa.</p>
        </div>
      </form>
    </div>
  )
}

function PerAssignee({ tasks }) {
  const stats = useMemo(() => {
    const map = new Map()
    tasks.forEach(t => {
      const k = t.assignedToName || '(Sem atribuição)'
      if (!map.has(k)) map.set(k, { count: 0, sum: 0, weights: 0, weightedSum: 0 })
      const o = map.get(k)
      o.count += 1
      o.sum += Number(t.progress) || 0
      o.weights += Number(t.weight) || 0
      o.weightedSum += (Number(t.weight)||0) * (Number(t.progress)||0)
    })
    return Array.from(map.entries()).map(([name, v]) => ({
      name,
      avg: v.count ? Math.round(v.sum / v.count) : 0,
      wavg: v.weights ? Math.round(v.weightedSum / v.weights) : 0,
      count: v.count,
    }))
  }, [tasks])
  return (
    <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
      {stats.map(p => (
        <div key={p.name} className="bg-white border rounded-2xl p-4 shadow-sm">
          <div className="flex items-center justify-between">
            <div><p className="font-semibold">{p.name}</p><p className="text-xs text-gray-600">{p.count} tarefa(s)</p></div>
            <div className="text-right"><p className="text-sm text-gray-600">Média</p><p className="text-xl font-bold">{p.avg}%</p></div>
          </div>
          <div className="mt-3"><label className="text-xs text-gray-600">Média ponderada</label><ProgressBar value={p.wavg} /></div>
        </div>
      ))}
      {stats.length === 0 && <div className="text-center text-gray-600 py-12 border rounded-2xl bg-white">Sem colaboradores ainda.</div>}
    </div>
  )
}

function StatCard({ icon, title, value, hint }) {
  return (
    <div className="bg-white border rounded-2xl p-4 shadow-sm">
      <div className="flex items-center gap-3">
        <div className="p-2 rounded-xl bg-gray-900 text-white">{icon}</div>
        <div>
          <p className="text-xs text-gray-600">{title}</p>
          <p className="text-2xl font-bold leading-tight">{value}</p>
          <p className="text-xs text-gray-500 mt-1">{hint}</p>
        </div>
      </div>
    </div>
  )
}

function ProgressBar({ value }) {
  return (
    <div className="w-full h-3 rounded-full bg-gray-200 overflow-hidden mt-2">
      <div className="h-full bg-emerald-600" style={{ width: `${Math.max(0, Math.min(100, Number(value) || 0))}%` }} />
    </div>
  )
}

function formatDateBR(iso) {
  try { const [y,m,d] = iso.split('-'); return `${d}/${m}/${y}` } catch { return iso }
}

function queryWrap(col, ...conds) {
  return conds.length ? query(col, ...conds, orderBy('createdAt', 'desc')) : query(col, orderBy('createdAt', 'desc'))
}
